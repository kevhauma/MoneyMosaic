import Editor from '@monaco-editor/react';
import {
  FieldErrorIconProps,
  FieldLabelProps,
  FieldWithLabel,
  InputWrapper,
  FieldErrorIcon,
} from './atoms';

type Props = FieldErrorIconProps &
  FieldLabelProps & {
    code: string;
    onChange?: (newValue: string) => void;
    language?: string;
    disabled?: boolean;
    hideLineNumbers?: boolean;
    editable?: boolean;
  };

export const CodeBlock = ({
  code,
  language = 'vb',
  onChange,
  label,
  errorMessage,
}: Props) => {
  const amountOfLines = code.split(/\r?\n/g).length;
  const height = amountOfLines * 18;

  return (
    <FieldWithLabel label={label}>
      <InputWrapper
        error={Boolean(errorMessage)}
        sx={{ minHeight: `${height + 15}px`, height: '100%' }}
      >
        <Editor
          language={language}
          value={code}
          onValidate={(marker) => console.log({ marker })}
          onChange={(value) => {
            onChange?.(`${value}`);
          }}
          options={{
            minimap: { enabled: false },
            scrollbar: {
              vertical: 'hidden',
              alwaysConsumeMouseWheel: false,
              ignoreHorizontalScrollbarInContentHeight: true,
            },
            automaticLayout: true,
            scrollBeyondLastLine: false,
          }}
        />
        <FieldErrorIcon errorMessage={errorMessage} />
      </InputWrapper>
    </FieldWithLabel>
  );
};
