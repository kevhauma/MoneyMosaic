import {
  IconButton,
  InputAdornment,
  TextField,
  TextFieldProps,
} from '@mui/material';
import { t } from 'i18next';
import { Eye, EyeOff, KeyVariant } from 'mdi-material-ui';
import { useState } from 'react';

export const PasswordField = (props: TextFieldProps) => {
  const [hidePassword, setHidePassword] = useState(true);

  return (
    <TextField
      label={t('login.password')}
      fullWidth
      type={hidePassword ? 'password' : 'text'}
      autoComplete="off"
      InputProps={{
        startAdornment: (
          <InputAdornment position="start">
            <KeyVariant />
          </InputAdornment>
        ),
        endAdornment: (
          <IconButton onClick={() => setHidePassword((toggle) => !toggle)}>
            {hidePassword ? <Eye /> : <EyeOff />}
          </IconButton>
        ),
      }}
      {...props}
    />
  );
};
