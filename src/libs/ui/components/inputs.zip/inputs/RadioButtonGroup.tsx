import { Stack } from '@mui/material';
import { RadioButton } from './RadioButton';
import { ErrorAndLabelProps, FieldWithLabel, FieldErrorIcon } from './atoms';

export type RadioButtonGroupProps = ErrorAndLabelProps & {
  options: Array<string | number | { label: string; value: string }>;
  value?: number | string;
  onChange: (value: string | number) => void;
};

export const RadioButtonGroup = ({
  options,
  value: selectedValue,
  onChange,
  label,
  errorMessage,
}: RadioButtonGroupProps) => {
  return (
    <FieldWithLabel label={label}>
      <Stack direction={'row'} gap={1}>
        {options.map((option) => {
          const value = typeof option === 'object' ? option.value : option;
          return (
            <RadioButton
              key={value}
              option={option}
              checked={value === selectedValue}
              onChange={onChange}
            />
          );
        })}
        {<FieldErrorIcon errorMessage={errorMessage}></FieldErrorIcon>}
      </Stack>
    </FieldWithLabel>
  );
};
