'use client';
import { Box, InputBase, InputBaseProps, Popover } from '@mui/material';
import { MouseEvent, useState } from 'react';
import ColorLensIcon from '@mui/icons-material/ColorLens';

import { ColorPicker as ColorPalette, useColor } from 'react-color-palette';
import 'react-color-palette/css';
import { ColorSquare } from '../ColorSquare';
import {
  ErrorAndLabelProps,
  FieldWithLabel,
  InputWrapper,
  FieldErrorIcon,
} from './atoms';

export type ColorPickerProps = {
  inputProps: InputBaseProps;
  colorPickerProps: { onChange: (color: string) => void; color?: string };
} & ErrorAndLabelProps;

export const ColorPicker = ({
  errorMessage,
  inputProps,
  colorPickerProps,
  label,
}: ColorPickerProps) => {
  const { sx, ...inputPropsWithoutSx } = inputProps;
  const [anchorEl, setAnchorEl] = useState<HTMLDivElement | null>(null);
  const { onChange: onColorPickerChange } = colorPickerProps;
  const [colorPickerColor, setColorPickerColor] = useColor(
    colorPickerProps.color ?? '#FFF'
  );

  const onClose = () => {
    onColorPickerChange(colorPickerColor.hex.toUpperCase());
    setAnchorEl(null);
  };

  const handleClick = (event: MouseEvent<HTMLDivElement>) => {
    setAnchorEl(event.currentTarget);
  };

  return (
    <FieldWithLabel label={label}>
      <InputWrapper
        sx={inputProps.sx}
        error={Boolean(errorMessage)}
        disabled={inputProps.disabled}
        onClick={handleClick}
      >
        <ColorSquare color={`${inputProps.value}`} />
        <InputBase sx={{ flex: 1, ml: 1 }} {...inputPropsWithoutSx} />
        <FieldErrorIcon errorMessage={errorMessage} />
        <ColorLensIcon />
      </InputWrapper>
      <Popover
        open={Boolean(anchorEl)}
        onClose={onClose}
        anchorEl={anchorEl}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'center',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'center',
        }}
      >
        <Box sx={{ width: '250px' }}>
          <ColorPalette
            onChange={setColorPickerColor}
            color={colorPickerColor}
            hideAlpha
            height={100}
            hideInput={['hsv']}
          />
        </Box>
      </Popover>
    </FieldWithLabel>
  );
};
