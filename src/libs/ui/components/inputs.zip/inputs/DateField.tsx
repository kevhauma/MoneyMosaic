import * as React from 'react';
import dayjs from 'dayjs';
import { DatePicker, DatePickerProps } from '@mui/x-date-pickers';
import { InputAdornment } from '@mui/material';
import { ErrorAndLabelProps, FieldWithLabel, FieldErrorIcon } from './atoms';

export type DateFieldProps<T> = DatePickerProps<T> & ErrorAndLabelProps;

export const DateField = <T,>({
  value,
  label,
  errorMessage,
  ...props
}: DateFieldProps<T>) => (
  <FieldWithLabel label={label}>
    <DatePicker
      timezone="UTC"
      format="DD MMM YYYY"
      //ts ignore because DayJs type does not adhere to "FieldValues" type, but still works
      //@ts-ignore
      value={value ? dayjs.utc(value) : null}
      slots={{
        inputAdornment: ({ children, ...props }) => {
          return (
            <InputAdornment {...props}>
              {errorMessage && <FieldErrorIcon errorMessage={errorMessage} />}
              {children}
            </InputAdornment>
          );
        },
      }}
      slotProps={{
        textField: {
          error: Boolean(errorMessage),
        },
      }}
      {...props}
    />
  </FieldWithLabel>
);
