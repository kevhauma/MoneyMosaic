import { InputBase, InputBaseProps } from '@mui/material';
import {
  ErrorAndLabelProps,
  FieldErrorIcon,
  FieldWithLabel,
  InputWrapper,
} from './atoms';
export type TextFieldProps = InputBaseProps &
  ErrorAndLabelProps & { dirty?: boolean };

export const TextField = ({
  sx,
  errorMessage,
  dirty,
  label,
  ...props
}: TextFieldProps) => {
  return (
    <FieldWithLabel label={label}>
      <InputWrapper
        sx={sx}
        error={Boolean(errorMessage)}
        disabled={props.disabled}
        dirty={dirty}
      >
        <InputBase
          sx={{ flex: 1, ml: 1 }}
          {...props}
          value={props.value || ''}
        />
        <FieldErrorIcon errorMessage={errorMessage} />
      </InputWrapper>
    </FieldWithLabel>
  );
};
