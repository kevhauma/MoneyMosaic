import {
  Autocomplete as MuiAutocomplete,
  AutocompleteProps as MuiAutocompleteProps,
  Stack,
  Typography,
} from '@mui/material';
import TextField from '@mui/material/TextField';
import { FieldErrorIconProps, FieldErrorIcon } from './atoms';

type AutocompleteProps<T> = Omit<
  MuiAutocompleteProps<T, true, undefined, undefined>,
  'renderInput'
> & { showValueInSelect?: boolean };

export const MultiAutocomplete = <T extends { value: string; label: string }>({
  errorMessage,
  value: selectedValues,
  onChange,
  showValueInSelect,
  ...props
}: AutocompleteProps<T> & FieldErrorIconProps) => {
  return (
    <MuiAutocomplete
      multiple
      onChange={onChange}
      value={selectedValues}
      renderInput={(params) => {
        const { InputProps, ...paramsWithNoInputProps } = params;
        const { endAdornment, ...inputPropsWithoutEndAdorment } = InputProps;
        return (
          <TextField
            {...paramsWithNoInputProps}
            error={Boolean(errorMessage)}
            InputProps={{
              ...inputPropsWithoutEndAdorment,
              endAdornment: errorMessage ? (
                <>
                  {endAdornment}
                  <FieldErrorIcon errorMessage={errorMessage} />
                </>
              ) : undefined,
            }}
          />
        );
      }}
      filterOptions={(options, state) =>
        options.filter(
          (option) =>
            option.value
              .toLowerCase()
              .includes(state.inputValue.toLowerCase()) ||
            option.label.toLowerCase().includes(state.inputValue.toLowerCase())
        )
      }
      renderOption={
        showValueInSelect
          ? (props, option) => {
              return (
                <li {...props}>
                  <Stack>
                    <Typography lineHeight={1.2} fontSize={'0.8rem'}>
                      {/* @ts-ignore */}
                      {option.label}
                    </Typography>
                    <Typography
                      variant="body2"
                      color="grey.600"
                      fontSize={'0.8rem'}
                    >
                      {/* @ts-ignore */}
                      {option.displayValue || option.value}
                    </Typography>
                  </Stack>
                </li>
              );
            }
          : undefined
      }
      {...props}
    />
  );
};
