import { TextareaAutosize, TextareaAutosizeProps } from '@mui/material';
import styled from '@emotion/styled';
import {
  ErrorAndLabelProps,
  FieldWithLabel,
  InputWrapper,
  FieldErrorIcon,
} from './atoms';

const StyledTextArea = styled(TextareaAutosize)`
  width: 100%;
  border: none;
  outline: none;
  :disabled {
    background: ${({ theme, disabled }) =>
      disabled ? theme.palette.grey[300] : theme.palette.grey[100]};
  }
`;
export type TextAreaProps = TextareaAutosizeProps &
  ErrorAndLabelProps & { dirty?: boolean };

export const TextArea = ({
  errorMessage,
  dirty,
  value,
  disabled,
  label,
  ...props
}: TextAreaProps) => {
  return (
    <FieldWithLabel label={label}>
      <InputWrapper
        disabled={disabled}
        error={Boolean(errorMessage)}
        dirty={dirty}
      >
        <StyledTextArea value={value || ''} disabled={disabled} {...props} />
        <FieldErrorIcon errorMessage={errorMessage} />
      </InputWrapper>
    </FieldWithLabel>
  );
};
