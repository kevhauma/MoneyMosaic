import {
  Box,
  Autocomplete as MuiAutocomplete,
  AutocompleteProps as MuiAutocompleteProps,
  Stack,
  Typography,
} from '@mui/material';
import TextField from '@mui/material/TextField';
import { PropsWithChildren } from 'react';
import { ErrorAndLabelProps, FieldWithLabel, FieldErrorIcon } from './atoms';

type AutoCompleteSelectOptions = { label: string; value: string };

export const getFilteredOptions = (
  options: AutoCompleteSelectOptions[],
  search?: string | null
) =>
  options.filter(
    (option) =>
      option.value.toLowerCase().includes(search?.toLowerCase() || '') ||
      option.label.toLowerCase().includes(search?.toLowerCase() || '')
  );

export type AutocompleteProps = ErrorAndLabelProps &
  PropsWithChildren &
  Omit<
    MuiAutocompleteProps<
      AutoCompleteSelectOptions,
      undefined,
      undefined,
      undefined
    >,
    'renderInput'
  > & {
    showValueInSelect?: boolean;
    dirty?: boolean;
    placeholder?: string;
  };

export const Autocomplete = ({
  errorMessage,
  showValueInSelect,
  placeholder,
  dirty,
  options,
  label,
  children,
  ...props
}: AutocompleteProps) => {
  return (
    <FieldWithLabel label={label}>
      <MuiAutocomplete
        options={options.toSorted((option1, option2) =>
          option1.label >= option2.label ? 1 : -1
        )}
        renderInput={(params) => {
          const { InputProps, ...paramsWithNoInputProps } = params;
          const { endAdornment, ...inputPropsWithoutEndAdorment } = InputProps;
          return (
            <Box sx={{ position: 'relative' }}>
              <TextField
                {...paramsWithNoInputProps}
                error={Boolean(errorMessage)}
                placeholder={placeholder}
                disabled={props.disabled}
                InputProps={{
                  ...inputPropsWithoutEndAdorment,
                  sx: dirty
                    ? {
                        borderWidth: 1,
                        borderStyle: 'solid',
                        borderColor: 'info.main',
                      }
                    : {},
                  endAdornment: (
                    <>
                      {endAdornment}
                      {errorMessage ? (
                        <FieldErrorIcon errorMessage={errorMessage} />
                      ) : undefined}
                    </>
                  ),
                }}
              />
              {children && (
                <Stack
                  sx={{
                    position: 'absolute',
                    top: 0,
                    right: 0,
                    height: '100%',
                    marginRight: '-46px',
                  }}
                  justifyContent={'center'}
                >
                  {children}
                </Stack>
              )}
            </Box>
          );
        }}
        getOptionKey={(option) => option.value}
        getOptionLabel={(selectedOption) =>
          //if the selectedOption is only the value (no label property), find the option in the optionsList
          selectedOption?.label ||
          options.find(
            (option) =>
              `${option.value}` === `${selectedOption?.value || selectedOption}`
          )?.label ||
          ''
        }
        filterOptions={(_, state) =>
          getFilteredOptions([...options], state.inputValue)
        }
        renderOption={
          showValueInSelect
            ? (props, option) => {
                return (
                  <li {...props}>
                    <Stack>
                      <Typography lineHeight={1.2} fontSize={'0.8rem'}>
                        {/* @ts-ignore */}
                        {option.label}
                      </Typography>
                      <Typography
                        variant="body2"
                        color="grey.600"
                        fontSize={'0.8rem'}
                      >
                        {/* @ts-ignore */}
                        {option.value}
                      </Typography>
                    </Stack>
                  </li>
                );
              }
            : undefined
        }
        {...props}
      />
    </FieldWithLabel>
  );
};
