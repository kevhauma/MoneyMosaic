import Refresh from '@mui/icons-material/Refresh';
import Check from '@mui/icons-material/Check';
import { Box, Stack } from '@mui/material';
import { keyframes } from '@mui/material/styles';
import styled from '@emotion/styled';
import { shouldForwardProp } from '@/libs/utils';
import { ErrorAndLabelProps, FieldWithLabel, FieldErrorIcon } from './atoms';

export type CheckboxProps = ErrorAndLabelProps & {
  checked: boolean;
  onChange?: Function;
  loading?: boolean;
};

const spin = keyframes`
  0% {
    transform: rotate(0);
  }
  100% {
    transform: rotate(360deg);
  }
`;
const Spin = styled(Box)`
  display: flex;
  justify-content: center;
  align-itmes: center;
  animation: ${spin} 2s ease-in-out infinite;
`;

const StyledBox = styled(Box, {
  shouldForwardProp: shouldForwardProp<{ checked: boolean }>(['checked']),
})<{ checked: boolean }>`
  color: green;
  width: 26px;
  height: 26px;
  backgroud: white;
  border-radius: 4px;
  border: ${({ theme, checked }) =>
      checked ? theme.palette.primary.main : theme.palette.grey[500]}
    1px solid;
  :hover {
    cursor: pointer;
  }
`;

export const Checkbox = ({
  checked,
  onChange,
  loading,
  errorMessage,
  label,
}: CheckboxProps) => {
  return (
    <FieldWithLabel label={label}>
      <Stack direction={'row'}>
        <StyledBox checked={checked} onClick={() => onChange?.(!checked)}>
          {loading && (
            <Spin>
              <Refresh />
            </Spin>
          )}
          {checked && !loading && <Check />}
        </StyledBox>
        {errorMessage && <FieldErrorIcon errorMessage={errorMessage} />}
      </Stack>
    </FieldWithLabel>
  );
};
