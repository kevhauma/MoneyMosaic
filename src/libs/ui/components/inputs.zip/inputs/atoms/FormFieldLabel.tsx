import { Grid, Typography } from '@mui/material';

import { PropsWithChildren } from 'react';

export const FormFieldLabel = ({ children }: PropsWithChildren) => (
  <Grid
    container
    item
    md={3}
    justifyContent={'flex-end'}
    alignContent={'center'}
  >
    <Typography paragraph={false} align="right" fontSize={14}>
      {children}
    </Typography>
  </Grid>
);
