import { Tooltip } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import ErrorIcon from '@mui/icons-material/Error';
import { FieldError, FieldErrorsImpl, Merge } from 'react-hook-form';

export type FieldErrorIconProps = {
  errorMessage?: string | FieldError | Merge<FieldError, FieldErrorsImpl<any>>;
};

export const FieldErrorIcon = ({ errorMessage }: FieldErrorIconProps) => {
  const theme = useTheme();
  return errorMessage ? (
    <Tooltip title={errorMessage.toString()}>
      <ErrorIcon htmlColor={theme.palette.error.main} />
    </Tooltip>
  ) : null;
};
