import { PropsWithChildren } from 'react';
import { FormFieldLabel } from './FormFieldLabel';
import { Grid } from '@mui/material';

export type FieldLabelProps = { label?: string | null };

export const FieldWithLabel = ({
  label,
  children,
}: PropsWithChildren & FieldLabelProps) => {
  if (label === undefined) return children;
  return (
    <Grid container spacing={2} maxWidth={'100%'}>
      <FormFieldLabel>{label}</FormFieldLabel>
      <Grid item flex={1}>
        {children}
      </Grid>
    </Grid>
  );
};
