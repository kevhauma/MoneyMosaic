import { FieldErrorIconProps } from './FieldErrorIcon';
import { FieldLabelProps } from './FieldWithLabel';

export type ErrorAndLabelProps = FieldLabelProps & FieldErrorIconProps;
