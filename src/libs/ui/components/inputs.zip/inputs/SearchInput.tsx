import { InputBase, InputBaseProps } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import Mousetrap from 'mousetrap';
import { ReactNode, useEffect, useRef } from 'react';
import { shortcutOnOS } from '@/libs/utils';
import { InputWrapper } from './atoms';

export type InputBasePropsBasicOnChange = Omit<InputBaseProps, 'onChange'> & {
  onChange?: (p1: string | null) => void;
};

type SearchInputProps = InputBasePropsBasicOnChange & {
  disableSearchShortcut?: boolean;
  renderInput?: (props: InputBasePropsBasicOnChange) => ReactNode;
};

export const SearchInput = ({
  sx,
  inputProps,
  disableSearchShortcut,
  renderInput,
  onChange,
  ...props
}: SearchInputProps) => {
  const ref = useRef<HTMLElement>();
  useEffect(() => {
    if (disableSearchShortcut) return;
    Mousetrap.bind(['ctrl+f', 'command+f'], (e) => {
      e?.preventDefault?.();
      ref.current?.focus();
    });

    return () => {
      Mousetrap.unbind(['ctrl+f', 'command+f']);
    };
    // eslint-disable-next-line
  }, []);

  return (
    <InputWrapper sx={sx}>
      <SearchIcon fontSize="small" />
      {renderInput ? (
        <>
          {renderInput({
            inputProps: { ref: ref, ...inputProps },
            sx: { flex: 1, ml: 1 },
            onChange,
            ...props,
          })}
        </>
      ) : (
        <InputBase
          inputProps={{ ref: ref, ...inputProps }}
          sx={{ flex: 1, ml: 1 }}
          onChange={(event) => onChange?.(event.target.value)}
          {...props}
        />
      )}
      {!disableSearchShortcut && shortcutOnOS('CTRL + F')}
    </InputWrapper>
  );
};
