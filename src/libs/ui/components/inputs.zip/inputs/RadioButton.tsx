import { shouldForwardProp } from '@/libs/utils';
import styled from '@emotion/styled';
import { Stack, Box } from '@mui/material';

const StyledCircle = styled(Box, {
  shouldForwardProp: shouldForwardProp<{ checked: boolean }>(['checked']),
})<{ checked: boolean }>`
  color: green;
  width: 26px;
  height: 26px;
  backgroud: white;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 50%;
  border: ${({ theme, checked }) =>
      checked ? theme.palette.primary.main : theme.palette.grey[500]}
    1px solid;
  :hover {
    cursor: pointer;
  }
`;

const StyledInnerCircle = styled(Box)`
  color: green;
  width: 16px;
  height: 16px;
  background: ${({ theme }) => theme.palette.primary.main};
  border-radius: 50%;
`;

type RadioButtonProps<
  T extends string | number | { label: string; value: string | number }
> = {
  checked: boolean;
  option: T;
  onChange?: (p1: string | number) => void;
};
export const RadioButton = <
  T extends string | number | { label: string; value: string }
>({
  checked,
  onChange,
  option,
}: RadioButtonProps<T>) => {
  return (
    <Stack gap={1} direction={'row'}>
      <StyledCircle
        checked={checked}
        onClick={() =>
          onChange?.(typeof option === 'object' ? option.value : option)
        }
      >
        {checked && <StyledInnerCircle />}
      </StyledCircle>
      {typeof option === 'object' ? option.label : option}
    </Stack>
  );
};
